Assignment 1
=====================
Assignment 1 of the UW online C++ course. This program creates a vector
graphic and a point from data parsed in an xml file.
