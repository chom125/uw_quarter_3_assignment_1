//Tyler Morgan
//UW online c++ cert class quarter 3
//main.cpp

#include <iostream>
#include "vector_graphic.h"


int main()
{
  std::cout << "here is where main will go.";
}
